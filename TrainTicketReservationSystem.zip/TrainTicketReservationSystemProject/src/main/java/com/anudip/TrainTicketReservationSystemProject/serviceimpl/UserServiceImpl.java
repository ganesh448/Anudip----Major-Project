package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.anudip.TrainTicketReservationSystemProject.Exception.UserFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.User;
import com.anudip.TrainTicketReservationSystemProject.repository.UserRepository;
import com.anudip.TrainTicketReservationSystemProject.service.UserService;

@Service
public class UserServiceImpl implements UserService {   //UserServiceImpl implementing the UserService interface.

    @Autowired   // Annotation that marks a field for automatic dependency injection by Spring.
    private UserRepository userRepository;   // automatically injected by Spring.
    
    
    @Override              // this method overrides a method from the UserService interface.
    public User createUser(User user) throws UserFoundException {
        // Check if the user with the same email already exists
        User existingUser = getUserByEmail(user.getEmail());
        if (existingUser != null) {
            throw new UserFoundException("User with the email " + user.getEmail() + " already exists.");
        }

        // Continue with user creation logic
        return userRepository.save(user);
    }


    @Override
    public User getUserById(Long userId) {
    	// Log a message to check if the method is being invoked
        System.out.println("Getting user by ID: " + userId);
        // Implementation for getting a user by ID
     // Implementation for getting a user by ID
        User user = userRepository.findById(userId).orElse(null);

        // Log the result
        if (user != null) {
            System.out.println("User found: " + user);
        } else {
            System.out.println("User not found with ID: " + userId);
        }

        return user;
    }

    @Override
    public User getUserByEmail(String email) {
        // Implementation for getting a user by email
        return userRepository.findByEmail(email);
    }

    @Override
    public User updateUser(User user) {
        // Implementation for updating a user
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long userId) {
        // Implementation for deleting a user
        userRepository.deleteById(userId);
    }

    @Override
    public List<User> getAllUsers() {
        // Implementation for getting all users
        return userRepository.findAll();
    }

 /*   @Override
    public void addUserRole(User user, String role) {
        // Implementation for adding a role to a user
        user.getRoles().add(role);
        userRepository.save(user);
    }*/

    @Override
    public void removeUserRole(User user, String role) {
        // Implementation for removing a role from a user
        user.getRoles().remove(role);
        userRepository.save(user);
    }

    @Override
    public boolean hasRole(User user, String role) {
        // Implementation for checking if a user has a specific role
        return user.getRoles() != null && user.getRoles().contains(role);
    }

    @Override
    public void changePassword(User user, String newPassword) {
        // Implementation for changing a user's password
        user.setPassword(newPassword);
        userRepository.save(user);
    }

    @Override
    public void lockUserAccount(User user) {
        // Implementation for locking a user account
        user.setAccountLocked(true);
        userRepository.save(user);
    }

    @Override
    public void unlockUserAccount(User user) {
        // Implementation for unlocking a user account
        user.setAccountLocked(false);
        userRepository.save(user);
    }

    @Override
    public Set<String> getUserRoles(User user) {
        // Implementation for getting user roles
        return user.getRoles();
    }

	@Override
	public void addUserRole(User user, String role) {
		 Set<String> roles = user.getRoles();

		    if (roles == null) {
		        roles = new HashSet<>();
		    }

		    roles.add(role);
		    user.setRoles(roles);

		    userRepository.save(user);
		
	}


}
