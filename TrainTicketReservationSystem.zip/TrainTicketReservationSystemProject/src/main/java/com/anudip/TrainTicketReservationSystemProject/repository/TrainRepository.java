package com.anudip.TrainTicketReservationSystemProject.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.anudip.TrainTicketReservationSystemProject.entity.Train;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {
	
	    Train findByName(String name);

	    List<Train> findByCapacityGreaterThan(int capacity);

	    List<Train> findByCapacityLessThan(int capacity);
	    
	    List<Train> findByCapacityBetween(int minCapacity, int maxCapacity);


}
