package com.anudip.TrainTicketReservationSystemProject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.entity.Train;
import com.anudip.TrainTicketReservationSystemProject.serviceimpl.TrainServiceImpl;


@RestController
@RequestMapping("/trains")
public class TrainController {
	
	@Autowired
    private TrainServiceImpl trainService;

    // Get all trains
    @GetMapping    //localhost:8080/trains
    public ResponseEntity<List<Train>> getAllTrains() {
        List<Train> trains = trainService.getAllTrains();
        return new ResponseEntity<>(trains, HttpStatus.OK);
    }

    // Get a specific train by ID
    @GetMapping("/{id}")   //localhost:8080/trains/id?id=12763
    public ResponseEntity<Train> getTrainById(@RequestParam Long id) {
        Train train = trainService.getTrainById(id);
        return train != null
                ? new ResponseEntity<>(train, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Create a new train
    
    @PostMapping    //localhost:8080/trains
    public ResponseEntity<Train> saveTrain(@RequestBody Train train) {
        Train savedTrain = trainService.saveTrain(train);
        return new ResponseEntity<>(savedTrain, HttpStatus.CREATED);
    }

    // Delete a train by ID
    @DeleteMapping("/{id}")   //localhost:8080/trains/{id}
    public ResponseEntity<Void> deleteTrain(@RequestParam Long id) {
        trainService.deleteTrain(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
