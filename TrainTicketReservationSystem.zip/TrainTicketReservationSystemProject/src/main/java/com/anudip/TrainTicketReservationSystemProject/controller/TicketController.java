package com.anudip.TrainTicketReservationSystemProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.entity.Ticket;
import com.anudip.TrainTicketReservationSystemProject.serviceimpl.TicketServiceImpl;


@RestController
@RequestMapping("/tickets")
public class TicketController {
	@Autowired
    private TicketServiceImpl ticketService;

    @GetMapping
    public List<Ticket> getAllTickets() {
        return ticketService.getAllTickets();
    }

    @GetMapping("/{id}")
    public Ticket getTicketById(@RequestParam Long id) {
        return ticketService.getTicketById(id);
    }

    @PostMapping
    public Ticket saveTicket(@RequestBody Ticket ticket) {
        return ticketService.saveTicket(ticket);
    }

    @DeleteMapping("/{id}")
    public void deleteTicket(@RequestParam Long id) {
        ticketService.deleteTicket(id);
    }

    @GetMapping("/booking/{bookingDetailsId}")
    public List<Ticket> getTicketsByBookingDetailsId(@RequestParam Long bookingDetailsId) {
        return ticketService.getTicketsByBookingDetailsId(bookingDetailsId);
    }

    @GetMapping("/seat/{seatNumber}")
    public List<Ticket> getTicketsBySeatNumber(@RequestParam String seatNumber) {
        return ticketService.getTicketsBySeatNumber(seatNumber);
    }
}
