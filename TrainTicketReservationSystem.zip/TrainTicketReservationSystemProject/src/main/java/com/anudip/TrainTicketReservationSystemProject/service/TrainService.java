package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;


import com.anudip.TrainTicketReservationSystemProject.entity.Train;

public interface TrainService {

	List<Train> getAllTrains();

    Train getTrainById(Long id);

    Train saveTrain(Train train);

    void deleteTrain(Long id);

	

}
