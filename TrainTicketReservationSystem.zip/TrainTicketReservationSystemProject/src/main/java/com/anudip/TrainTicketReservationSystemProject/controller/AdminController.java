package com.anudip.TrainTicketReservationSystemProject.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.Exception.FoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.NotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Admin;
import com.anudip.TrainTicketReservationSystemProject.serviceimpl.AdminServiceImpl;

@RestController
@RequestMapping("/TrainTicketReservation")
public class AdminController {
	
	@Autowired
    AdminServiceImpl adminserviceimpl;	
	
	
	@GetMapping("/admin")  //localhost:8080/TrainTicketReservation/admin
	public ResponseEntity<List<Admin>>getAllAdmins() throws NotFoundException
	{
		List<Admin> newadmin=adminserviceimpl.getAllRecords();
		return new ResponseEntity<>(newadmin,HttpStatus.OK);
	}
	
	@PostMapping("/admin")  //localhost:8080/TrainTicketReservation/admin
	public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) throws FoundException 
	{
		Admin newadmin=adminserviceimpl.saveAdmin(admin);
		return new ResponseEntity<>(newadmin,HttpStatus.CREATED);
		}
		
	
	@GetMapping("/admin/{id}")   //localhost:8080/TrainTicketReservation/admin/Mouni
	public ResponseEntity<Admin> getAdminById(@PathVariable String id) throws NotFoundException{

		Admin admin=adminserviceimpl.getAdmin(id);
		return new ResponseEntity<>(admin,HttpStatus.OK);

	}
	
	@PutMapping("/admin/{id}")  //localhost:8080/TrainTicketReservation/admin/Mouni
	public ResponseEntity<Admin> updateAdmin(@PathVariable String id,@RequestBody Admin admin) throws NotFoundException{
		Admin updateadmin=new Admin();
		updateadmin.setLoginid(id);
		updateadmin.setPassword(admin.getPassword());
		Admin updateadminnew=adminserviceimpl.updateAdmin(admin);
		return new ResponseEntity<>(updateadminnew,HttpStatus.OK);

	}
	
	@DeleteMapping("/admin/{id}")   //localhost:8080/TrainTicketReservation/admin/Mouni
	public String deleteAdmin(@PathVariable String id) throws NotFoundException
	{
		return adminserviceimpl.deleteAdmin(id);
	}
	
	@ExceptionHandler(NotFoundException.class)
    public ResponseEntity<?> exceptionHandler(NotFoundException ex) {
        return ResponseEntity.ok(ex.getMessage());
    }
	@ExceptionHandler(FoundException.class)
    public ResponseEntity<?> exceptionHandler(FoundException ex) {
        return ResponseEntity.ok(ex.getMessage());
    }
}
