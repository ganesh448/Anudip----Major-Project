package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.TrainTicketReservationSystemProject.entity.Train;
import com.anudip.TrainTicketReservationSystemProject.repository.TrainRepository;
import com.anudip.TrainTicketReservationSystemProject.service.TrainService;

@Service
public class TrainServiceImpl implements TrainService {
	@Autowired
    private TrainRepository trainRepository;

    @Override
    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    @Override
    public Train getTrainById(Long id) {
        return trainRepository.findById(id).orElse(null);
    }

    @Override
    public Train saveTrain(Train train) {
        return trainRepository.save(train);
    }

    @Override
    public void deleteTrain(Long id) {
        trainRepository.deleteById(id);
    }

}
