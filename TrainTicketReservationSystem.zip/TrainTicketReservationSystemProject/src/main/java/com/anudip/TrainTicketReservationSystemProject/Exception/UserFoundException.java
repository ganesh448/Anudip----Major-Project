package com.anudip.TrainTicketReservationSystemProject.Exception;

import java.io.Serializable;

public class UserFoundException extends Exception implements Serializable {

    private static final long serialVersionUID = 1L;

    public UserFoundException(String message) {
        super(message);
    }

    @Override
    public void printStackTrace() {
        // Custom implementation if needed
        super.printStackTrace();
    }


}
