package com.anudip.TrainTicketReservationSystemProject.serviceimpl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.anudip.TrainTicketReservationSystemProject.Exception.FoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.NotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Admin;
import com.anudip.TrainTicketReservationSystemProject.repository.AdminRepository;
import com.anudip.TrainTicketReservationSystemProject.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public List<Admin> getAllRecords()throws NotFoundException {
		// TODO Auto-generated method stub
		List<Admin> adminlist=adminRepository.findAll();
		if(adminlist.isEmpty()) 
		{
			throw new NotFoundException("NO records are there.Please create Admin First!");
		}
		else
			return adminlist;
	}

	@Override
	public Admin saveAdmin(Admin admin) throws FoundException {
		// TODO Auto-generated method stub
	
		Optional<Admin> existadmin=adminRepository.findById(admin.getLoginid());
		if(existadmin.isPresent())
		{
			throw new FoundException("This admin already exist! Please login with other loginid");
		}
		else
			return adminRepository.save(admin);	
	}

	@Override
	public Admin getAdmin(String id) throws NotFoundException{
		// TODO Auto-generated method stub
		Optional<Admin> checkadmin=adminRepository.findById(id);
		if(checkadmin.isPresent())
		{
			return adminRepository.findById(id).get();
		}
		else
		{
			throw new NotFoundException("There is No Admin with this id");
		}
	}

	@Override
	public Admin updateAdmin(Admin admin) throws NotFoundException{
		// TODO Auto-generated method stub
		Optional<Admin> checkadmin=adminRepository.findById(admin.getLoginid());
		if(checkadmin.isPresent())
		{
			return adminRepository.save(admin);
		}
		else
		{
			throw new NotFoundException("There is No Admin with this id");
		}
	}

	@Override
	public String deleteAdmin(String id) throws NotFoundException{
		// TODO Auto-generated method stub
		Optional<Admin> checkadmin=adminRepository.findById(id);
		if(checkadmin.isPresent())
		{
			adminRepository.deleteById(id);
			return "Record deleted";
		}
		else
		{
			throw new NotFoundException("There is No Admin with this id");
		}
		
	}

}
