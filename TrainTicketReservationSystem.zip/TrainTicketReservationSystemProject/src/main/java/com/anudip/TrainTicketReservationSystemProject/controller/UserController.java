package com.anudip.TrainTicketReservationSystemProject.controller;
import org.springframework.http.HttpStatus;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.anudip.TrainTicketReservationSystemProject.Exception.UserFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.User;
import com.anudip.TrainTicketReservationSystemProject.service.UserService;

@RestController    //It combines @Controller and @ResponseBody.
@RequestMapping("/users")   //controller will handle requests.
public class UserController {
	
    @Autowired   //Annotation that marks a field for automatic dependency injection by Spring.
    private UserService userService;  //will be automatically injected by Spring
    
    //http://localhost:8080/users/create
    @PostMapping("/create") //Handles HTTP POST requests.
    public User createUser(@RequestBody User user) throws UserFoundException  {
        return userService.createUser(user);
    }
    @ExceptionHandler(UserFoundException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public String handleUserFoundException(UserFoundException e) {
        return "User creation failed: " + e.getMessage();
    }
    
    
  //http://localhost:8080/users/{userId}
    @GetMapping("/{userId}")   // Handles HTTP GET requests for retrieving a user by ID.
    public User getUserById(@PathVariable Long userId) {
        return userService.getUserById(userId);
    }
    
    
    //http://localhost:8080/users/email/{email}
    @GetMapping("/email/{email}")  //Handles HTTP GET requests for retrieving a user by email.
    public User getUserByEmail(@PathVariable String email) {
        return userService.getUserByEmail(email);
    }
    
    
  //http://localhost:8080/users/1
    @PutMapping ("/{userId}")        //Handles HTTP PUT requests
    public User updateUser(@RequestBody User user) {
        return userService.updateUser(user);
    }
    
    
    //http://localhost:8080/users/{userId}
    @DeleteMapping("/{userId}") //Handles HTTP DELETE requests.
    public void deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
    }
    
    
    //http://localhost:8080/users/all
    @GetMapping("/all")  // Handles HTTP GET request to get all users
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    
    
    //http://localhost:8080/users/{userId}/changePassword?newPassword=newpassword
    @PutMapping("/{userId}/changePassword")  //Handles HTTP PUT requests for changing a user's password.
    public void changePassword(@PathVariable Long userId, @RequestParam String newPassword) {
        User user = userService.getUserById(userId);
        userService.changePassword(user, newPassword);
    }
    
    
    //http://localhost:8080/users/{userId}/lock
    @PutMapping("/{userId}/lock")  //Handles HTTP PUT requests for locking a user account.
    public void lockUserAccount(@PathVariable Long userId) {
        User user = userService.getUserById(userId);
        userService.lockUserAccount(user);
    }
    
    
    //http://localhost:8086/users/{userId}/unlock
    @PutMapping("/{userId}/unlock") //Handles HTTP PUT requests for unlocking a user account.
    public void unlockUserAccount(@PathVariable Long userId) {
        User user = userService.getUserById(userId);
        userService.unlockUserAccount(user);
    }
    
    
    //http://localhost:8086/users/{userId}/addRole?roleName=ROLE_ADMIN
    @PutMapping("/{userId}/addRole")//Handles HTTP PUT requests for adding a role to a user.
    public void addUserRole(@PathVariable Long userId, @RequestParam String roleName) {
        User user = userService.getUserById(userId);
        userService.addUserRole(user, roleName);
    }
    
    
    //http://localhost:8086/users/{userId}/removeRole?roleName=USER_ROLE
    @PutMapping("/{userId}/removeRole") // Handles HTTP PUT requests for removing a role from a user.
    public void removeUserRole(@PathVariable Long userId, @RequestParam String roleName) {
        User user = userService.getUserById(userId);
        userService.removeUserRole(user, roleName);
    }
    
    //http://localhost:8086/users/{userId}/hasRole?roleName=ROLE_ADMIN
    @GetMapping("/{userId}/hasRole")  //: Handles HTTP GET requests for checking if a user has a specific role.
    public boolean hasRole(@PathVariable Long userId, @RequestParam String roleName) {
        User user = userService.getUserById(userId);
        return userService.hasRole(user, roleName);
    }


}
