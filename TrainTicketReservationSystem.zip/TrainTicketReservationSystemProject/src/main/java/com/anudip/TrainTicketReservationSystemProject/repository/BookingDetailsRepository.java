package com.anudip.TrainTicketReservationSystemProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anudip.TrainTicketReservationSystemProject.entity.BookingDetails;
@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetails, Long> {

	List<BookingDetails> findByUserId(Long userId);

    List<BookingDetails> findByTrainId(Long trainId);
    
    List<BookingDetails> findByNumberOfSeats(int numberOfSeats);

    List<BookingDetails> findByUserIdAndTrainId(Long userId, Long trainId);


}
