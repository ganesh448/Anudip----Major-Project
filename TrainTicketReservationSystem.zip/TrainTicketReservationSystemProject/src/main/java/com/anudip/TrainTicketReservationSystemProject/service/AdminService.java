package com.anudip.TrainTicketReservationSystemProject.service;

import java.util.List;

import com.anudip.TrainTicketReservationSystemProject.Exception.FoundException;
import com.anudip.TrainTicketReservationSystemProject.Exception.NotFoundException;
import com.anudip.TrainTicketReservationSystemProject.entity.Admin;

public interface AdminService {
	
	List<Admin> getAllRecords() throws NotFoundException;
	
	Admin saveAdmin(Admin admin)  throws FoundException;
	
	Admin getAdmin(String id) throws NotFoundException;
	
	Admin updateAdmin(Admin admin) throws NotFoundException;
	
	String deleteAdmin(String id) throws NotFoundException;

}
