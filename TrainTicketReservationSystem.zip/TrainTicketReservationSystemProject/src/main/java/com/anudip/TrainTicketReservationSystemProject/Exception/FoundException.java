package com.anudip.TrainTicketReservationSystemProject.Exception;

public class FoundException extends Exception{

	public FoundException() {
		super("This user id is already present in database");
		
	}
	public FoundException(String message) {
		super(message);
		
	}

}
